Source: provided by client for PlugHub PDF Service branding (saved as logo.png).
